@if($errors->any())
    <div>
        <strong>There sre some problem with your input.<br><br>
        <ul>
            @foreach($errors->all() as $error)
                <li> {{$error}} </li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ ('createQuizUser') }}" method="POST">
	@csrf    
	<strong>
		Please Enter FormID:
	</strong>
	<input type="text" name="create_user_id" placeholder="only numeric">
    <strong>
		Please Enter Your Name:
	</strong>
	<input type="text" name="name" placeholder="name">
	<button>Submit</button>
</form>