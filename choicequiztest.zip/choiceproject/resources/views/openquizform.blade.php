@if($errors->any())
    <div>
        <strong>There are some problem with your input.<br><br>
        <ul>
            @foreach($errors->all() as $error)
                <li> {{$error}} </li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ ('storequiz') }}" method="POST">
@csrf
    <div class="">
        <div class="">
            Kindly fill your choice
        </div>

@foreach($formid as $id)
<h3><strong>Please note down your form number.</strong>
<input type="text" name="formid" value="{{$id->id}}" readonly="" style="width:30px;"></h3>
@endforeach
		

        <?php //dd($questions) ?>
    @if(count($questions) > 0)
        <div class="">
        <?php $i = 1; ?>
        @foreach($questions as $question)
            @if ($i > 1) <hr /> @endif
            <div class="">
                <div class="">
                    <div class="">
                        <strong>Question {{ $i }}.<br />{!! nl2br($question->question_text) !!}</strong>
                        <input
                            type="hidden"
                            name="questions[{{ $i }}]"
                            value="{{ $question->id }}">
                    @foreach($question->options as $option)
                        <br>
                        <label class="">
                            <input
                                type="radio"
                                name="answers[{{ $question->id }}]"
                                value="{{ $option->id }}">
                            {{ $option->option }}
                        </label>
                    @endforeach
                    </div>
                </div>
            </div>
        <?php $i++; ?>
        @endforeach
        </div>
    @endif
    </div>
	<button>Submit</button>
</form>