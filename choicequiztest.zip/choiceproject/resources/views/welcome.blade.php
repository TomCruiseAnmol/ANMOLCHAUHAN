<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <style>
            *{
                box-sizing: border-box;
            }
            body {
                font-family: 'Nunito';
                margin: 0;
            }
            .heading{
                width: 100%;
                height: 50px;
            }
            .heading h2{
                margin-left: 10%;
                font-size: 1.8vw;
                color: green;
            }
            .linkbutton{
                width: 70%;
                margin: auto;
                height: 50px;
                margin-top: 20px;                
            }
            a{
                text-decoration: none;
                font-size: 1.5vw;
                color: brown;  
                border: 1px solid lightgray;
                border-radius: 25px;
                padding: 3px;              
            }
            #createlink{
                float: left;
                margin-left: 20px;
                margin-top: 10px;
            }
            #fillanswer{
                float: right;
                margin-top: 10px;
                margin-right: 20px;
            }
        </style>
    </head>
    <body>
        <div class="heading">
            <h2>WELCOME, Here you can create your own questions and answered them to check who know you well</h2>
        </div>
        <div class="linkbutton">
            <a href="createlink" id="createlink">Create Your Link</a>
            <a href="fillanswer" id="fillanswer">Give Answers</a>

        </div>
    </body>
</html>
