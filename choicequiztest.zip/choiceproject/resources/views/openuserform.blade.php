@if($errors->any())
    <div>
        <strong>There sre some problem with your input.<br><br>
        <ul>
            @foreach($errors->all() as $error)
                <li> {{$error}} </li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ ('createUser') }}" method="POST">
	@csrf    
	<strong>
		Enter Your Name:
	</strong>
	<input type="text" name="name" placeholder="Name">
	<button>Submit</button>
</form>