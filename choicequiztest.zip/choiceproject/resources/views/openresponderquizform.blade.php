@if($errors->any())
    <div>
        <strong>There are some problem with your input.<br><br>
        <ul>
            @foreach($errors->all() as $error)
                <li> {{$error}} </li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ ('createanswer') }}" method="POST">
@csrf
    

@foreach($formid as $id)
<div class="">
        <div class="">
            Kindly fill form for
        </div>
<h3><strong>Form Number.</strong>
<input type="text" name="formid" value="{{$id->create_user_id}}" readonly="" style="width:30px;"></h3>
@endforeach

@foreach($resuserid as $id)
<div class="">
<input type="text" name="responseid" value="{{$id->id}}" readonly="" hidden="" style="width:30px;">
@endforeach
		

        <?php //dd($questions) ?>
    @if(count($questions) > 0)
        <div class="">
        <?php $i = 1; ?>
        @foreach($questions as $question)
            @if ($i > 1) <hr /> @endif
            <div class="">
                <div class="">
                    <div class="">
                        <strong>Question {{ $i }}.<br />
                        @foreach($question->que_text as $que)
                        {!! nl2br($que->question_text) !!}</strong>
                        @endforeach
                        <input
                            type="hidden"
                            name="questions[{{ $i }}]"
                            value="{{ $question->id }}">
                    @foreach($question->options as $option)
                        <br>
                        <label class="">
                            <input
                                type="radio"
                                name="answers[{{ $question->id }}]"
                                value="{{ $option->id }}">
                            {{ $option->option }}
                        </label>
                    @endforeach
                    </div>
                </div>
            </div>
        <?php $i++; ?>
        @endforeach
        </div>
    @endif
    </div>
	<button>Submit</button>
</form>