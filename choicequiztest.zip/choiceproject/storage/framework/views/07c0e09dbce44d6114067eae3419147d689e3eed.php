<?php if($errors->any()): ?>
    <div>
        <strong>There sre some problem with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(('createQuizUser')); ?>" method="POST">
	<?php echo csrf_field(); ?>    
	<strong>
		Please Enter FormID:
	</strong>
	<input type="text" name="create_user_id" placeholder="only numeric">
    <strong>
		Please Enter Your Name:
	</strong>
	<input type="text" name="name" placeholder="name">
	<button>Submit</button>
</form><?php /**PATH C:\Users\TOM CRUISE\Desktop\laravel\choiceproject\resources\views/openquizanswerform.blade.php ENDPATH**/ ?>