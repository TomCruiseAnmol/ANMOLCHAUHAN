<?php if($errors->any()): ?>
    <div>
        <strong>There are some problem with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(('storequiz')); ?>" method="POST">
<?php echo csrf_field(); ?>
    <div class="">
        <div class="">
            Kindly fill your choice
        </div>

<?php $__currentLoopData = $formid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><strong>Please note down your form number.</strong>
<input type="text" name="formid" value="<?php echo e($id->id); ?>" readonly="" style="width:30px;"></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		

        <?php //dd($questions) ?>
    <?php if(count($questions) > 0): ?>
        <div class="">
        <?php $i = 1; ?>
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($i > 1): ?> <hr /> <?php endif; ?>
            <div class="">
                <div class="">
                    <div class="">
                        <strong>Question <?php echo e($i); ?>.<br /><?php echo nl2br($question->question_text); ?></strong>
                        <input
                            type="hidden"
                            name="questions[<?php echo e($i); ?>]"
                            value="<?php echo e($question->id); ?>">
                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <br>
                        <label class="">
                            <input
                                type="radio"
                                name="answers[<?php echo e($question->id); ?>]"
                                value="<?php echo e($option->id); ?>">
                            <?php echo e($option->option); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php $i++; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    </div>
	<button>Submit</button>
</form><?php /**PATH C:\Users\TOM CRUISE\Desktop\laravel\choiceproject\resources\views/openquizform.blade.php ENDPATH**/ ?>