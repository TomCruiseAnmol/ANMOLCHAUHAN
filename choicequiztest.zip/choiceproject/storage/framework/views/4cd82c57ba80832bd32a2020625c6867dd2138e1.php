<?php if($errors->any()): ?>
    <div>
        <strong>There sre some problem with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(('createUser')); ?>" method="POST">
	<?php echo csrf_field(); ?>    
	<strong>
		Enter Your Name:
	</strong>
	<input type="text" name="name" placeholder="Name">
	<button>Submit</button>
</form><?php /**PATH C:\Users\TOM CRUISE\Desktop\laravel\choiceproject\resources\views/openuserform.blade.php ENDPATH**/ ?>