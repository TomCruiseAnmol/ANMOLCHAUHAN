<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CreateUserQuiz extends Model
{
    use HasFactory;
    protected $fillable = ['create_user_id','question_id','answer_id'];
}
