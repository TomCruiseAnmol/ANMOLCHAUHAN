<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\Question;
use App\Models\Answer;
use App\Models\createuser;
use App\Models\createuserquiz;

class QuizuserController extends Controller
{
    
    public function insertUser(REQUEST $request){        
        $request->validate([                       
            'name' => 'required',
        ]);

        createuser::create($request->all());

        $formid = DB::select('select id from create_users order by id DESC LIMIT 1');

        $questions = Question::inRandomOrder()->limit(10)->get();
        foreach ($questions as &$question) {
            $question->options = Answer::where('question_id', $question->id)->inRandomOrder()->get();
        }        
    return view('openquizform',compact('questions'),['formid'=>$formid])->with('success', 'Your record inserted successfully.....');
    }

    public function findQuiz(REQUEST $request)
    {
    	//$quizquestion = DB::select('select * from questions');
        //$quizanswer = DB::select('select * from answers');     
    }

    public function addQuiz(REQUEST $request)
    {
        $request->validate([            
        ]);        
        //createuserquiz::create($request->all());

        foreach ($request->input('questions', []) as $key => $question) {

            CreateUserQuiz::create([
                'create_user_id' => $request->formid,
                'question_id'    => $question,
                'answer_id'      => $request->input('answers.'.$question),                
            ]);
            
        }

        return redirect('/');
    }    
}
