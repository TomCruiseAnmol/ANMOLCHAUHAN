<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\Question;
use App\Models\Answer;
use App\Models\createuser;
use App\Models\createuserquiz;
use App\Models\responder;
use App\Models\responderanswer;


class QuizrespondedController extends Controller
{
    //
    public function insertQuizUser(REQUEST $request)
    {
        $request->validate([                       
            'create_user_id' => 'required',
            'name' => 'required',
        ]);

        Responder::create($request->all());

        $formid = DB::select('select create_user_id from responders order by id DESC LIMIT 1');
        $resuserid = DB::select('select id from responders order by id DESC LIMIT 1');
        $questions = CreateUserQuiz::inRandomOrder()->limit(10)->get();
        foreach ($questions as &$question) {            
            $question->que_text = Question::where('id', $question->id)->get();
            $question->options = Answer::where('question_id', $question->id)->inRandomOrder()->get();
        }
        return view('openresponderquizform',compact('questions'),['formid'=>$formid,'resuserid'=>$resuserid])->with('success', 'Your record inserted successfully.....');
    }

    public function addAnswer(REQUEST $request)
    {
        foreach ($request->input('questions', []) as $key => $question) {

            ResponderAnswer::create([
                'create_user_id' => $request->responseid,
                'question_id'    => $question,
                'answer_id'      => $request->input('answers.'.$question),                
            ]);
            
        }
        return redirect('/');
    }
}
