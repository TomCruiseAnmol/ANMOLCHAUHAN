<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InsertAnswer extends Controller
{
    //
}
