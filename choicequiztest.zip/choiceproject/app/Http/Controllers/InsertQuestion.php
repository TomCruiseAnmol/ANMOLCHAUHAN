<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\Questions;

class InsertQuestion extends Controller
{
    //
    public function addQuestion(){
    	$question = array('1' => 'What is my name?',
    	'2' => 'Where am i live?',
    	'3' => 'What is my age?',
    	'4' => 'what do i like?',
    	'5' => 'i have traveled.',
    	'6' => 'I am work for.',
    	'7' => 'My best friend name is.',
    	'8' => 'which perfume i like',
    	'9' => 'what, i have completed in my study',
    	'10' => 'what type of person am i?', );
    
    	DB::table('questions')->insert($question);

    
    //return redirect('welcome');
	}
	
}
