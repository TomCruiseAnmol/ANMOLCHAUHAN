<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateResponderAnswersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('responder_answers', function (Blueprint $table) {
            $table->increments('id');

            $table->integer('responder_id')->unsigned()->nullable();
            $table->foreign('responder_id', 'fk_265_responder_responder_id_responder_answer')->references('id')->on('responders');
            $table->integer('question_id')->unsigned()->nullable();
            $table->foreign('question_id', 'fk_264_question_question_id_responder_answer')->references('id')->on('questions');
            $table->integer('answer_id')->unsigned()->nullable();
            $table->foreign('answer_id', 'fk_263_answer_answer_id_responder_answer')->references('id')->on('answers');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('responder_answers');
    }
}
