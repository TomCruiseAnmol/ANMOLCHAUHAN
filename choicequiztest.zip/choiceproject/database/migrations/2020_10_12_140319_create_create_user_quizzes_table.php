<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCreateUserQuizzesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('create_user_quizzes', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('create_user_id')->unsigned()->nullable();
            $table->foreign('create_user_id', 'fk_258_create_user_create_user_id_create_user_quiz')->references('id')->on('create_users');
            $table->integer('question_id')->unsigned()->nullable();
            $table->foreign('question_id', 'fk_259_question_question_id_create_user_quiz')->references('id')->on('questions');
            $table->integer('answer_id')->unsigned()->nullable();
            $table->foreign('answer_id', 'fk_260_answer_answer_id_create_user_quiz')->references('id')->on('answers');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('create_user_quizzes');
    }
}
